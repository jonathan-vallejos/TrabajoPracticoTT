/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package TrabajoPracticoJonathanVallejossTT;

import java.util.Scanner;

/**
 *
 * @author jonat
 */
public class Ejercicio1 {

    public static void main(String[] args) {
       
        
        resolverEjercicio1();
        
    } // ---- MAIN ----
    
   
    
    public static void resolverEjercicio1(){
        int[] notas = crearArregloNotas();
        
        System.out.println("Las notas obtenidas:");
        for(int a:notas) System.out.println(a); // Esto muestra las notas
        
        System.out.println("El Promedio de las notas es: " + promedioNotas(notas));
        
        //Aprobado
        /*if(promedioNotas(notas) > 0){
            if(promedioNotas(notas) >= 6){
                System.out.println("Aprobado");
            }else if(promedioNotas(notas) < 6){
                for (int i=0; i<notas.length; i++){
                    if (notas [i] <= 3){
                        System.out.println("No Aprobado");
                    }else if(notas [i] >3){
                        System.out.println("A Recuperatorio");
                    }
                }     
            }
           
        }*/
        
        /*for (int i=0; i<notas.length; i++){
            
            if(promedioNotas(notas) >= 6){
                System.out.println("Aprobado");
                
            }else if(promedioNotas(notas) < 6 && notas[i] <=3){
                System.out.println("No Aprobado");
                
            }else if(promedioNotas(notas) <6 && notas[i] >3){
                System.out.println("A Recuperatorio");
            }else{
                System.out.println(" ");
            }          
            
        }*/
        if(promedioNotas(notas) > 6) System.out.println("Aprobado");
        if(promedioNotas(notas) < 6) {
            for (int i=0; i<notas.length; i++){
                if(notas[i] <=3){
                    System.out.println("No Aprobado");break;
                }
            }
        }
        if(promedioNotas(notas) < 6){
            for (int i=0; i<notas.length; i++){
                if(notas[i] >3){
                    System.out.println("A Recuperatorio");break;
                }
            }
        }
            
        
        
        /*if(promedioNotas(notas) < 6){
            for (int i=0; i<notas.length; i++){
                if(notas[i] <= 3){
                    System.out.println("No Aprobado"); break;
                }if(notas[i] >3){
                    System.out.println("A Recuperatorio");break;
                }else{
                    System.out.println("Aprobado");
                }
            }
                    
        }*/
     
        /*switch(promedioNotas(notas)){
            case 1: 
                for (int i=0; i<notas.length; i++){
                    if(notas[i] <=3){
                        System.out.println("No Aprobado"); return;
                    }
                }
                System.out.println("A Recuperatorio");break;
            case 2: System.out.println("Aprobado");break;
        }*/
        
        /*switch(promedioNotas(notas)){
            case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    for (int i = 0; i < notas.length; i++) {
                        if (notas[i] <= 3) {
                            System.out.println("NO APROBADO");
                            return;
                        }
                    }
                    System.out.println("A RECUPERATORIO");
                    break;
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                    System.out.println("APROBADO");
                    break;
                default:
                    System.out.println("El promedio ingresado no es válido.");
                    break;
        }*/
    }
    
    
    public static int[] crearArregloNotas(){
        Scanner teclado = new Scanner(System.in);
        System.out.println("¿Cuántos notas quiere guardar?");
        int longitud = teclado.nextInt();
        int[] notas = new int[longitud];
        
        System.out.println("Por favor ingrese los "+longitud+" valores:");
        for (int i=0; i<notas.length; i++) {
            System.out.print("Ingrese la Nota N°"+(i+1)+" - ");
            notas[i] = teclado.nextInt();
        }
        
        
        return notas;        
    }
    
    public static int promedioNotas (int[] notas){
        int suma = 0;
        for(int a:notas) suma+=a;
        int promedio = suma / notas.length;
        return promedio;
    }
    
}
